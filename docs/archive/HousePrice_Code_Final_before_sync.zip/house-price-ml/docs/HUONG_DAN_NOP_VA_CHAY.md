# Bộ code nộp cuối: TRAIN/TEST + HomeValue Lab

## 1. Cài và chạy trên Windows

Giải nén ZIP. Mở PowerShell **trong thư mục house-price-ml có requirements.txt**.
Máy cần Python (đã kiểm thử với 3.12) và Node.js (đã kiểm thử với 24.22.1).

Cài thư viện một lần:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
npm ci
```

Chạy giao diện tích hợp với một lệnh:

```powershell
.\.venv\Scripts\python.exe scripts/start_demo.py
```

Trình duyệt tự mở http://localhost:3000/#/data. Nhấn Ctrl+C tại PowerShell để dừng cả hai server.
Không cần chạy train_compare.py trước demo: trọng số và kết quả đã nằm trong gói.

Hoặc mở hai PowerShell tại thư mục này:

```powershell
# Cửa sổ 1
.\.venv\Scripts\python.exe service/ui_service.py
# Cửa sổ 2
node ui_server.js
```

`npm start` và `service/predict_service.py` là lệnh của bản form đơn giản lịch sử.
Để xem giao diện đầy đủ của bản nộp, dùng start_demo.py hoặc hai lệnh ở trên.
Form cũ có thể xem tại http://localhost:3000/legacy.html khi chạy ui_server.js.

## 2. Thứ tự demo

1. **Train / Test**: xem quy trình dữ liệu gốc, nhấn “Chạy kiểm nghiệm lại 5 mô hình”.
   API nạp đúng trọng số đã lưu, predict lại 1.168 TRAIN và 292 TEST; không huấn luyện trong request.
   Bảng hiện MAE/RMSE/R², tỷ lệ sai lệch ≤5/10/20%, đối chiếu CSV gốc, CV trên TRAIN và giới hạn.
   Có nút xuất JSON/CSV và chuyển 292 căn sang so sánh.
2. **Dự đoán mô hình**: chọn một trong 5 model. Tra ID trong train.csv để có đủ đặc trưng và nhãn gốc;
   hoặc nhập căn mới (thiếu cột dùng defaults). Nhấn dự đoán để xem giá, sai số nếu có nhãn,
   biểu đồ, các bước suy luận và hệ số/feature importance. Sửa đặc trưng căn đã tra sẽ bỏ nhãn gốc tự động.
3. **So sánh mô hình**: chọn 30 holdout, chọn 30 train để thấy hiệu ứng đo trên dữ liệu đã học,
   hoặc tải CSV riêng. Chọn model và nhấn chạy. Biểu đồ giá và biểu đồ chỉ số có điều khiển riêng.
   Banner đỏ khi có TRAIN; xanh khi toàn holdout đủ 30; vàng khi có nhãn chưa xác minh hoặc mẫu nhỏ.
   Chỉ số chính ưu tiên nhóm holdout; bảng nguồn dữ liệu ghi riêng từng nhóm. JSON/CSV tải về giữ toàn bộ dự đoán.
4. Mở bảng Excel/CSV trong results/chuan_hoa để trình bày số liệu tính sẵn.

## 3. Kết quả TRAIN/TEST nằm ở đâu?

| Tệp | Nội dung |
|---|---|
| results/model_results.csv | Bảng gốc USD, bảo toàn |
| results/chuan_hoa/02_ket_qua_TRAIN.csv | MAE/RMSE/R²/MAPE trên TRAIN của 5 model |
| results/chuan_hoa/03_ket_qua_TEST.csv | Chỉ số trên 292 holdout, VND |
| results/chuan_hoa/04_ket_qua_CV_5fold.csv | Từng fold CV trên TRAIN, trung bình và độ lệch chuẩn |
| results/chuan_hoa/05_so_sanh_TRAIN_vs_TEST.csv | Khoảng cách TRAIN/TEST |
| results/chuan_hoa/06_du_doan_TEST_chi_tiet.csv | Giá gốc/dự đoán và sai số 292 × 5 |
| results/chuan_hoa/07_du_doan_TRAIN_chi_tiet.csv | Giá gốc/dự đoán và sai số 1.168 × 5 |
| results/chuan_hoa/BAO_CAO_KET_QUA_TRAIN_TEST.xlsx | 12 sheet tổng hợp để nộp/bảo vệ |
| results/training_holdout_report.json | Báo cáo tính lại từ các pipeline UI dùng |
| results/INTEGRATION_MODEL_COMPARISON.json | Độ lệch so với bảng chuẩn hóa trước khi tích hợp |
| results/INTEGRATION_CHECKS.json | Kết quả test tích hợp thực tế |
| results/INTEGRATION_HTTP_CHECKS.json | Kết quả HTTP thực tế qua Express → Flask |
| results/INTEGRATION_DOM_CHECKS.json | Kết quả thao tác JS trong jsdom; không thay thế browser thật |

## 4. Những gì được giữ và những gì được thêm

- Giữ dữ liệu, trọng số XGBoost gốc, script train/test/EDA/tiền xử lý và toàn bộ bảng số liệu chuẩn hóa.
- UI tích hợp nằm trong public/homevalue.html + app.js + styles.css; server mới ui_server.js + service/ui_service.py.
- Có models/ui/{linear,tree,forest,boosting,xgboost}.pkl và manifest để cả ba tab dùng cùng mô hình.
- Bốn model bổ sung tái lập từ đúng get_models() gốc, cùng split và tiền xử lý; từng dự đoán train/test được đối chiếu.
- XGBoost UI có thêm UBJSON và bộ tiền xử lý riêng để nạp tương thích nền tảng; best_model.pkl gốc không bị ghi đè.
- Không ghép trọng số tuning cũ của UI vào báo cáo chuẩn hóa. Mọi mô tả trong UI theo đúng thực nghiệm gốc.
- README gốc và hướng dẫn cũ được giữ để đối chiếu lịch sử. Hướng dẫn chạy bản nộp này là tài liệu hiện tại.

## 5. Kiểm thử lại

```powershell
.\.venv\Scripts\python.exe notebooks_or_src_py/verify_chuan_hoa.py
.\.venv\Scripts\python.exe notebooks_or_src_py/verify_du_doan_vnd.py
.\.venv\Scripts\python.exe scripts/verify_integration.py
```

Khi demo đang chạy, mở PowerShell khác:

```powershell
node notebooks_or_src_py/smoke_chuan_hoa.mjs
node scripts/smoke_integration.mjs
```

Test smoke lịch sử đọc form gốc ở /legacy.html (thay vì / của UI mới) nhưng vẫn kiểm tra nội dung form,
request, kết quả tiền VND và validation như cũ. Bản gốc script được lưu nguyên trong docs/original_smoke_chuan_hoa.mjs.

Kiểm tra giao diện bằng browser thật trên máy của bạn (tùy chọn):

```powershell
npm install --no-save --package-lock=false playwright
npx playwright install chromium
node scripts/browser_check.mjs
```

Trong môi trường tạo gói, tải Chromium bị lỗi nên không tuyên bố đã kiểm tra hiển thị bằng browser thật.
Đã kiểm tra thao tác UI bằng jsdom, JavaScript thật và API HTTP thật; kết quả ghi riêng.

## 6. Hạn chế học thuật cần nói rõ

- Thực nghiệm gốc chọn XGBoost theo MAE TEST; Gradient Boosting lại có CV MAE thấp hơn.
  Vì TEST đã tham gia chọn model nên cần một tập độc lập mới để đánh giá cuối.
- Pipeline gốc vẫn có **80 cột gồm Id**. Id có thể làm thay đổi dự đoán dù thông tin nhà giống nhau.
  Bản nộp giữ kết quả cũ theo yêu cầu chuẩn hóa; không tuyên bố đã sửa Id hoặc đã tuning.
- CV gốc: cross_val_score(..., cv=5, scoring='neg_mean_absolute_error') trên TRAIN, không shuffle.
- Đơn vị giá gốc USD, diện tích sqft. VND là quy đổi cố định 25.000 VND/USD từ Ames, Iowa 2006–2010;
  không phản ánh giá thị trường Việt Nam.
- Dòng TRAIN không chứng minh khả năng tổng quát hóa. Nhãn nhập tay là nhãn người dùng chưa xác minh.
- Không bảo đảm đúng giá từng căn. Thiếu đặc trưng, nhãn mới và dữ liệu ngoài miền có thể gây sai lệch.

## 7. Tái tạo model UI khi cần

Gói đã có đủ model. Chỉ dùng scripts/build_submission_models.py khi xây lại từ nguồn chuẩn hóa gốc
chưa có models/ui/manifest.json. Script từ chối ghi đè manifest có sẵn, không đổi best_model.pkl.
Không chạy train_compare.py tùy tiện trước buổi bảo vệ vì script lịch sử đó có thể ghi đè kết quả gốc.

## 8. Kiểm tra thao tác DOM (không cần Chromium)

Khi demo đang chạy: `npm install --no-save --package-lock=false jsdom`, rồi `node scripts/dom_check.cjs`.
Đây là jsdom gọi API thật, không phải kiểm tra bố cục bằng browser.
