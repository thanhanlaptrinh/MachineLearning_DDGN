/** Optional real-browser check. Install playwright + Chromium as documented. */
import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
const require=createRequire(import.meta.url);const {chromium}=require('playwright');
const browser=await chromium.launch({headless:true});const page=await browser.newPage();const errors=[];
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(['error','warning'].includes(m.type()))errors.push(m.text());});
try{
 for(const route of ['data','predict/xgboost','compare']){await page.goto('http://localhost:3000/#/'+route);await page.waitForFunction(()=>document.querySelector('#status')?.textContent.includes('5 mô hình'));await page.waitForTimeout(300);}
 if(errors.length)throw Error(errors.join('\n'));
 await fs.writeFile(new URL('../results/INTEGRATION_BROWSER_CHECKS.json',import.meta.url),JSON.stringify({passed:3,failed:0,errors},null,2));console.log('3 pages: no console errors or warnings');
}finally{await browser.close();}
