"""Tái lập bốn model cấu hình gốc, giữ best_model.pkl; kiểm chứng từng dự đoán."""
from pathlib import Path
import sys,json,hashlib,shutil,platform
import numpy as np,pandas as pd,joblib,sklearn,xgboost
from sklearn.pipeline import Pipeline
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'service'),str(ROOT/'notebooks_or_src_py')]
from preprocess import load_and_split,build_pipeline
from train_compare import get_models
from tien_te import TY_GIA_USD_VND
from audit_engine import CATALOG,split_data,metrics,fit_assessment,sha
from model_io import export_portable_xgboost,load_pipeline

def main():
 out=ROOT/'models/ui';out.mkdir(exist_ok=True)
 if (out/'manifest.json').exists(): raise FileExistsError('Đã có models/ui; không tự ghi đè. Chỉ chạy script này khi tái tạo gói từ nguồn gốc.')
 Xtr,Xte,ytr,yte=load_and_split(str(ROOT/'data/train.csv'))
 expected=pd.read_csv(ROOT/'results/chuan_hoa/06_du_doan_TEST_chi_tiet.csv')
 expected_train=pd.read_csv(ROOT/'results/chuan_hoa/07_du_doan_TRAIN_chi_tiet.csv')
 df=pd.read_csv(ROOT/'data/train.csv');baseline={k:metrics(y,np.full(len(y),ytr.mean())) for k,y in [('train',ytr),('test',yte)]}
 manifest={'winner':'xgboost','selection_rule':'Original TEST MAE; no tuning','versions':{'python':platform.python_version(),'sklearn':sklearn.__version__,'xgboost':xgboost.__version__},'models':{}}
 report={'models':{},'source_files':{f:sha(ROOT/f) for f in ['data/train.csv','data/test.csv','models/best_model.pkl','models/feature_defaults.json','results/model_results.csv']},'baseline':baseline,
 'demo_indices':[int(i) for i in Xte.index[:30]],'split':{'seed':42,'train_size':len(Xtr),'test_size':len(Xte),'demo_size':30,'train_ids':df.loc[Xtr.index,'Id'].astype(int).tolist(),'test_ids':df.loc[Xte.index,'Id'].astype(int).tolist()},
 'provenance':{'dataset':'Ames, Iowa 2006–2010; 80 đặc trưng gồm Id theo pipeline gốc. Id có thể ảnh hưởng dự đoán không có ý nghĩa.',
 'truth':'Nhãn gốc SalePrice trong CSV đã kiểm tra SHA-256; chưa xác minh giao dịch bên ngoài.',
 'selection':'Giữ lựa chọn gốc XGBoost theo MAE TEST. Gradient Boosting có CV MAE nhỏ hơn. Không thực hiện tuning hoặc sửa số liệu.',
 'limits':'TEST đã tham gia lựa chọn model ở code gốc; cần kiểm nghiệm mới độc lập. VND là quy đổi, không phải giá thị trường Việt Nam.'}}
 comparisons=[]
 for slug,name,_ in CATALOG:
  file=out/(slug+'.pkl')
  if slug=='xgboost':shutil.copy2(ROOT/'models/best_model.pkl',file);pipe=joblib.load(file)
  else:
   pipe=Pipeline([('preprocess',build_pipeline(Xtr)),('model',get_models()[name])]);pipe.fit(Xtr,ytr);joblib.dump(pipe,file,compress=3)
  max_diff={}
  for scope,X,y,stored in [('test',Xte,yte,expected),('train',Xtr,ytr,expected_train)]:
   pred=np.asarray(pipe.predict(X), dtype=float);part=stored[stored.Mo_hinh==name].set_index('Id').loc[df.loc[X.index,'Id']]
   delta=np.max(np.abs(pred*TY_GIA_USD_VND-part.Du_doan_VND.to_numpy()))
   assert np.allclose(pred*TY_GIA_USD_VND,part.Du_doan_VND,rtol=1e-10,atol=.01),(name,scope,delta)
   max_diff[scope+'_max_delta_vnd']=float(delta)
  scores={'train':metrics(ytr,pipe.predict(Xtr)),'test':metrics(yte,pipe.predict(Xte))}
  demo=Xte.iloc[:30];pred=pipe.predict(demo);scores['demo']=metrics(yte.iloc[:30],pred)
  info={'file':file.relative_to(ROOT).as_posix(),'sha256':sha(file),'target_transform':'identity'};manifest['models'][slug]=info
  report['models'][slug]={**info,'origin':'Trọng số XGBoost gốc, bảo toàn từng byte.' if slug=='xgboost' else 'Tái lập đúng get_models(), split và pipeline gốc; dự đoán train/test đối chiếu CSV chuẩn hóa.',
  'metrics':scores,'assessment':fit_assessment(scores['train'],scores['test'],baseline),'demo_predictions':{str(int(i)):float(p) for i,p in zip(df.loc[demo.index,'Id'],pred)}}
  comparisons.append({'model':name,**max_diff});print(name,max_diff,flush=True)
 (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,allow_nan=False))
 export_portable_xgboost(out/'xgboost.pkl')
 (ROOT/'results/vnd_audit_source.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
 (ROOT/'results/INTEGRATION_MODEL_COMPARISON.json').write_text(json.dumps(comparisons,ensure_ascii=False,indent=2))
 # Cross-platform loader must reproduce the original pipeline too.
 portable=load_pipeline(out/'xgboost.pkl');assert np.array_equal(portable.predict(Xte),joblib.load(ROOT/'models/best_model.pkl').predict(Xte))
 print('PASS: portable XGBoost prediction difference = 0 USD')
if __name__=='__main__':main()
