// Integration test using jsdom and real HTTP. This is not a Chromium rendering test.
const {JSDOM,VirtualConsole}=require('jsdom');
const fs=require('fs');const assert=require('assert/strict');const base='http://127.0.0.1:3000';
const checks=[],errors=[];let dom;
const wait=async(f,msg)=>{for(let i=0;i<400;i++){if(f())return;await new Promise(r=>setTimeout(r,50));}throw Error('timeout '+msg);};
(async()=>{
 const vc=new VirtualConsole();vc.on('jsdomError',e=>{if(!e.message.includes('Could not parse CSS'))errors.push(e.message)});
 dom=await JSDOM.fromURL(base+'/#/data',{resources:'usable',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.fetch=(url,opts)=>fetch(new URL(url,base),opts);}});
 const w=dom.window,d=w.document;
 await wait(()=>d.querySelector('#run-training-report'),'data page');checks.push('Train/Test initial page');
 d.querySelector('#run-training-report').click();await wait(()=>d.querySelector('#holdout-model'),'training report');assert.ok(d.querySelector('#training-status').textContent.includes('Cả 5'));checks.push('Train/Test report button and five model table');
 d.querySelector('#use-trained-best').click();await wait(()=>d.querySelector('#single-form'),'predict page');checks.push('Navigate to original winning model');
 for(const slug of ['linear','tree','forest','boosting','xgboost']){
  w.location.hash='#/predict/'+slug;await new Promise(r=>setTimeout(r,70));
  d.querySelector('#lookup-id').value='893';d.querySelector('#lookup-button').click();await wait(()=>d.querySelector('#input-source').textContent.includes('893'),'lookup');
  d.querySelector('#single-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await wait(()=>d.querySelector('#single-result').textContent.includes('₫'),'prediction '+slug);assert.equal(d.querySelector('#single-error').textContent,'');checks.push('Lookup, predict, trace '+slug);
 }
 w.location.hash='#/compare';await wait(()=>d.querySelector('#use-demo'),'compare page');d.querySelector('#use-demo').click();d.querySelector('#run-batch').click();await wait(()=>d.querySelector('.scope-banner.green'),'holdout compare');checks.push('Holdout compare green banner and charts');
 const before=d.querySelector('#chart-one').innerHTML;d.querySelector('#metric-apply').click();assert.equal(d.querySelector('#chart-one').innerHTML,before);checks.push('Metric control does not change price chart');
 d.querySelector('#use-train').click();await wait(()=>d.querySelector('#batch-name').textContent==='train-30','train dataset');d.querySelector('#run-batch').click();await wait(()=>d.querySelector('.scope-banner.red'),'train compare');assert.ok(d.querySelector('.scope-banner').textContent.includes('30/30'));checks.push('Train compare red warning and separate group metrics');
 assert.deepEqual(errors,[]);checks.push('No JavaScript runtime error in jsdom');
 fs.writeFileSync(require('node:path').join(__dirname,'../results/INTEGRATION_DOM_CHECKS.json'),JSON.stringify({passed:checks.length,failed:0,environment:'jsdom + live HTTP; not browser rendering',checks,errors},null,2));console.log(checks.length+' PASS; 0 FAIL (jsdom interactions)');
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>dom?.window.close());
