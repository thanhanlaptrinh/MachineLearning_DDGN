import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const base=process.env.DEMO_URL||'http://127.0.0.1:3000';const checks=[];
async function get(path,body){const r=await fetch(base+path,body?{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}:{});assert.equal(r.status,200,path);return r.json();}
function pass(name){checks.push(name);}
const health=await get('/api/health');assert.equal(health.models,5);pass('Express → Flask health, five models');
for(const path of ['/','/app.js','/styles.css','/favicon.svg','/legacy.html','/results/chuan_hoa/03_ket_qua_TEST.csv']){assert.equal((await fetch(base+path)).status,200);pass('GET '+path);}
assert.equal((await fetch(base+'/favicon.ico')).status,204);pass('favicon.ico no 404');
const report=await get('/api/training-report',{});assert.equal(report.all_match_original_report,true);assert.equal(report.models.length,5);assert.equal(report.winner,'xgboost');assert.equal(report.cv_winner,'boosting');pass('Saved models reproduce all five original report rows');
for(const [kind,scope,color] of [['train-30','train_only','red'],['holdout-30','holdout_only','green']]){const data=await get('/api/dataset/'+kind);const q=await get('/api/evaluate',{records:data.records});assert.equal(q.evaluation_scope,scope);assert.equal(q.banner_color,color);assert.equal(q.count,30);pass(kind+' scope and banner');}
const tr=await get('/api/dataset/train-30'),te=await get('/api/dataset/holdout-30');const mixed=await get('/api/evaluate',{records:[...tr.records.slice(0,15),...te.records.slice(0,15)]});assert.equal(mixed.evaluation_scope,'mixed');assert.equal(mixed.models[0].by_membership.train.n,15);assert.equal(mixed.models[0].by_membership.holdout.n,15);pass('Mixed data metrics separated 15/15');
for(const slug of ['linear','tree','forest','boosting','xgboost']){const q=await get('/api/evaluate',{models:[slug],records:te.records.slice(0,1),explain:true});assert.equal(q.models[0].trace.verified,true);assert.equal(q.models[0].metrics.r2,null);pass(slug+' single house inference, trace and null R2');}
const legacy=await get('/predict',{LotArea:8500,GrLivArea:1500,OverallQual:6,YearBuilt:2005,Neighborhood:'CollgCr',GarageType:'Attchd'});assert.equal(legacy.predicted_price_vnd,legacy.predicted_price_usd*legacy.usd_to_vnd);pass('Legacy payload and exact currency conversion');
assert.equal((await fetch(base+'/api/record/999999')).status,400);pass('Missing original Id gives useful 400');
await fs.writeFile(new URL('../results/INTEGRATION_HTTP_CHECKS.json',import.meta.url),JSON.stringify({passed:checks.length,failed:0,checks},null,2));console.log(`${checks.length} PASS; 0 FAIL`);
