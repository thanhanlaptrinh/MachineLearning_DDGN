"""Kiểm tra kết nối mô hình gốc/bảng kết quả/UI. Không fit hoặc sửa trọng số."""
import sys,json,hashlib
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'service'),str(ROOT/'notebooks_or_src_py')]
from audit_engine import AuditEngine,sha,fit_assessment,CATALOG,RATE
from flexible_engine import FlexibleEngine
from training_report import build_training_report
from model_io import load_pipeline

def main():
 checks=[]
 def check(name,value):
  checks.append({'name':name,'pass':bool(value)})
  if not value:raise AssertionError(name)
 engine=AuditEngine();f=FlexibleEngine(engine);before={p:sha(ROOT/p) for p in engine.report['source_files']}
 r=build_training_report(engine)
 check('5 models and original CSV agreement',len(r['models'])==5 and r['all_match_original_report'])
 check('Original TEST winner XGB; CV winner GB reported separately',r['winner']=='xgboost' and r['cv_winner']=='boosting')
 check('Original 80-feature schema including Id disclosed',len(f.columns)==80 and 'Id' in f.columns)
 for scope,X,filename in [('train',engine.X_train,'07_du_doan_TRAIN_chi_tiet.csv'),('test',engine.X_test,'06_du_doan_TEST_chi_tiet.csv')]:
  stored=pd.read_csv(ROOT/'results/chuan_hoa'/filename,float_precision='round_trip')
  for slug,name,_ in CATALOG:
   pred=np.asarray(engine.models[slug].predict(X),dtype=float)*RATE
   expected=stored[stored.Mo_hinh==name].set_index('Id').loc[engine.df.loc[X.index,'Id'],'Du_doan_VND'].to_numpy()
   check(f'{slug} {scope}: all rows match original predictions within .01 VND',np.allclose(pred,expected,rtol=0,atol=.01))
 for slug in engine.models:
  q=f.evaluate({'records':[{'source_id':engine.test_ids[0]}],'models':[slug],'explain':True})
  check(slug+' stage trace reconstructs direct prediction',q['models'][0]['trace']['verified'])
  check(slug+' single sample R2 undefined',q['models'][0]['metrics']['r2'] is None)
 sets=[('train_only',engine.train_ids[:30],'red',{'train':30}),('holdout_only',engine.test_ids[:30],'green',{'holdout':30}),('mixed',engine.train_ids[:15]+engine.test_ids[:15],'red',{'train':15,'holdout':15})]
 for scope,ids,color,counts in sets:
  result=f.evaluate({'records':[{'source_id':i} for i in ids]})
  check(scope+' scope and banner',result['evaluation_scope']==scope and result['banner_color']==color)
  for m in result['models']:
   check(scope+' '+m['id']+' separate groups', {k:v['n'] for k,v in m['by_membership'].items()}==counts)
   check(scope+' '+m['id']+' headline matches expected group',m['metrics']['n']==counts[result['headline_membership']])
  if scope=='train_only':train_result=result
  if scope=='holdout_only':holdout_result=result
 xtr=next(m for m in train_result['models'] if m['id']=='xgboost');xte=next(m for m in holdout_result['models'] if m['id']=='xgboost')
 check('XGB training sample optimism measured',xtr['metrics']['mae']<xte['metrics']['mae'])
 q=f.evaluate({'records':[{'features':{'GrLivArea':1500,'LotArea':8500},'actual_vnd':5e9}],'models':['xgboost']})
 check('User supplied label remains unverified',q['evaluation_scope']=='unverified_only' and q['rows'][0]['truth']=='user_supplied')
 for ratio,gap,expected in [(2.60,.0768,'Khoảng cách lớn'),(1.77,.0641,'Khoảng cách vừa'),(2.72,.0908,'Khoảng cách lớn'),(2.42,.179,'Khoảng cách lớn'),(1.33,.0336,'Khoảng cách nhỏ'),(1.1,.01,'Chưa thấy dấu hiệu rõ')]:
  a=fit_assessment({'mae':1,'r2':.99},{'mae':ratio,'r2':.99-gap},engine.report['baseline']);check('Fit rule '+str(ratio),a['label']==expected)
 check('Protected sources unchanged by evaluation',all(sha(ROOT/p)==h for p,h in before.items()))
 # Entire VND package source remains preserved except the documented README append.
 base=ROOT.parents[1]/'inspect/HousePrice_VND/house-price-ml'
 inventory=json.loads((ROOT/'results/INTEGRATION_SOURCE_HASHES.json').read_text())
 check('Every original VND source file preserved or appended README',all((sha(ROOT/'docs/original_verification'/Path(k).name)==v and '0 FAIL' in (ROOT/k).read_text()) if k in {'results/chuan_hoa/KIEM_CHUNG.md','results/chuan_hoa/KIEM_CHUNG_DU_DOAN.md','results/chuan_hoa/KIEM_CHUNG_HTTP.md'} else (sha(ROOT/'docs/original_smoke_chuan_hoa.mjs')==v if k=='notebooks_or_src_py/smoke_chuan_hoa.mjs' else sha(ROOT/k)==v if k!='README.md' else (ROOT/k).read_bytes().startswith((ROOT/'docs/README_before_integration.md').read_bytes())) for k,v in inventory.items()))
 (ROOT/'results/INTEGRATION_CHECKS.json').write_text(json.dumps({'passed':len(checks),'failed':0,'checks':checks},ensure_ascii=False,indent=2))
 (ROOT/'results/training_holdout_report.json').write_text(json.dumps(r,ensure_ascii=False,indent=2,allow_nan=False))
 print(f'{len(checks)} PASS; 0 FAIL')
if __name__=='__main__':main()
