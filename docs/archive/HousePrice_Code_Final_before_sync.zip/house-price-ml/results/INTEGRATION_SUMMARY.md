# Kết quả tích hợp TRAIN/TEST + UI

Tổng kiểm tra: 261 PASS, 0 FAIL.

| Kiểm tra | PASS | FAIL |
|---|---:|---:|
| Chuẩn hóa TRAIN/TEST | 140 | 0 |
| Dự đoán tương thích bản gốc | 18 | 0 |
| HTTP và form lịch sử | 4 | 0 |
| Tích hợp model/báo cáo/nguồn nhãn | 66 | 0 |
| HTTP UI tích hợp | 19 | 0 |
| Thao tác UI bằng jsdom | 12 | 0 |
| Lệnh khởi động/dừng demo | 2 | 0 |

Xem output thật trong INTEGRATION_VERIFICATION_LOGS.txt và các JSON INTEGRATION_*.

## Đối chiếu dự đoán với CSV trước khi tích hợp

| Mô hình | Lệch tối đa TRAIN (VND) | Lệch tối đa TEST (VND) |
|---|---:|---:|
| Linear Regression | 1.90734863281e-06 | 1.90734863281e-06 |
| Decision Tree | 4.76837158203e-07 | 4.76837158203e-07 |
| Random Forest | 4.76837158203e-07 | 4.76837158203e-07 |
| Gradient Boosting | 1.90734863281e-06 | 1.90734863281e-06 |
| XGBoost | 0 | 0 |

Sai khác rất nhỏ ở bốn model là biểu diễn số thực/CSV. XGBoost bảo toàn trọng số và dự đoán; UBJSON portable được so sánh array_equal trên toàn TEST, độ lệch 0 USD.

Dữ liệu, trọng số và bảng chuẩn hóa bảo toàn; các báo cáo verify sinh lại có bản lịch sử trong docs/original_verification. File smoke lịch sử chỉ đổi URL form sang /legacy.html; bản gốc script nằm trong docs/.

## Giới hạn kiểm thử

Đã chạy HTTP thật và JavaScript thật bằng jsdom. Chromium tải thất bại (file tải không hợp lệ), nên chưa chứng nhận giao diện bằng browser thật. Có scripts/browser_check.mjs và hướng dẫn chạy tại máy nộp.

## Giới hạn học thuật được giữ minh bạch

Code gốc dùng 80 đặc trưng gồm Id, lựa chọn XGBoost theo MAE TEST. Không tuning trong lần tích hợp. Gradient Boosting có CV MAE thấp hơn; UI trình bày riêng. VND là quy đổi Ames, không đại diện thị trường Việt Nam.
