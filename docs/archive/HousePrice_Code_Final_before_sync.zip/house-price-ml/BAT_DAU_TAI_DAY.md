# Code nộp cuối — Nhóm 9

Đọc docs/HUONG_DAN_NOP_VA_CHAY.md để xem hướng dẫn hiện tại.

Giải nén, mở PowerShell trong thư mục này:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
npm ci
.\.venv\Scripts\python.exe scripts/start_demo.py
```

Mở http://localhost:3000/#/data. Không cần train lại.
Kết quả TRAIN/TEST và Excel nằm ở results/chuan_hoa/.
Trọng số XGBoost gốc bảo toàn; model UI dùng chung ở models/ui/.
README và HUONG_DAN_THANH có phần lịch sử; lệnh start_demo.py ở đây dành cho UI đầy đủ.
