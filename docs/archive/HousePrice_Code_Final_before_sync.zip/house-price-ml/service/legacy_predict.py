"""Tương thích form/CLI gốc, dùng cùng trọng số XGBoost với giao diện mới."""
import json
import pandas as pd
from audit_engine import ROOT,RATE
from model_io import load_pipeline
model=load_pipeline(ROOT/'models/ui/xgboost.pkl')
def predict_legacy(data):
 defaults=json.loads((ROOT/'models/feature_defaults.json').read_text())
 row={**defaults,**{k:v for k,v in data.items() if k in defaults}}
 try: raw=float(model.predict(pd.DataFrame([row]))[0])
 except Exception as exc: raise ValueError('Lỗi khi dự đoán: '+str(exc)) from exc
 return {'predicted_price':round(raw,2),'predicted_price_usd':raw,'predicted_price_vnd':raw*RATE,'usd_to_vnd':RATE,'used_input':data}
